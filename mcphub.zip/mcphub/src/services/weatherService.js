// -----------------------------------------------------------------------
// weatherService — will call a real weather API later.
// -----------------------------------------------------------------------
import { weatherToday, weatherForecast } from '../data/mockData'

const LATENCY = 150

function resolveAfter(value) {
  return new Promise((resolve) => setTimeout(() => resolve(value), LATENCY))
}

export function fetchWeatherToday() {
  return resolveAfter(weatherToday)
}

export function fetchWeatherForecast() {
  return resolveAfter(weatherForecast)
}
