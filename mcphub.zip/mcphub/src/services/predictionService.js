// -----------------------------------------------------------------------
// predictionService — will call the real ML model / MCP server later.
// -----------------------------------------------------------------------
import { getPrediction, getRecommendation, getBestMarketSuggestion } from '../data/mockData'

const LATENCY = 250

function resolveAfter(value) {
  return new Promise((resolve) => setTimeout(() => resolve(value), LATENCY))
}

export function fetchPrediction(cropId, marketId) {
  return resolveAfter(getPrediction(cropId, marketId))
}

export function fetchRecommendation() {
  return resolveAfter(getRecommendation())
}

export function fetchBestMarketSuggestion(cropId) {
  return resolveAfter(getBestMarketSuggestion(cropId))
}
