// -----------------------------------------------------------------------
// cropService — everything about crops, markets and current/historical prices.
// Every export resolves a Promise, mirroring a future fetch() call, so
// components already await data the same way real API integration will need.
// -----------------------------------------------------------------------
import { crops, markets, currentPrices, getHistoricalSeries, getMarketComparison } from '../data/mockData'

const LATENCY = 120

function resolveAfter(value) {
  return new Promise((resolve) => setTimeout(() => resolve(value), LATENCY))
}

export function fetchCrops() {
  return resolveAfter(crops)
}

export function fetchMarkets() {
  return resolveAfter(markets)
}

export function fetchCurrentPrice(cropId, marketId) {
  return resolveAfter(currentPrices[cropId]?.[marketId] ?? null)
}

export function fetchAllPricesForCrop(cropId) {
  const rows = markets.map((m) => currentPrices[cropId][m.id])
  return resolveAfter(rows)
}

export function fetchHistoricalSeries(cropId, marketId, days = 30) {
  return resolveAfter(getHistoricalSeries(cropId, marketId, days))
}

export function fetchMarketComparison(cropId) {
  return resolveAfter(getMarketComparison(cropId))
}
