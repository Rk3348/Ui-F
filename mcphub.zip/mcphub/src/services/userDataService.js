// -----------------------------------------------------------------------
// userDataService — history, notifications, profile. Backed by a real
// database/auth service later.
// -----------------------------------------------------------------------
import { analysisHistory, notifications, currentUser, recentlyAnalyzed } from '../data/mockData'

function resolveAfter(value, latency = 150) {
  return new Promise((resolve) => setTimeout(() => resolve(value), latency))
}

export function fetchAnalysisHistory() {
  return resolveAfter(analysisHistory)
}

export function fetchNotifications() {
  return resolveAfter(notifications)
}

export function fetchCurrentUser() {
  return resolveAfter(currentUser)
}

export function fetchRecentlyAnalyzed() {
  return resolveAfter(recentlyAnalyzed)
}
