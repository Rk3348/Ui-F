// -----------------------------------------------------------------------
// assistantService — will call the real MCP-backed AI assistant later.
// -----------------------------------------------------------------------
import { assistantSuggestions, getAssistantReply } from '../data/mockData'

export function fetchAssistantSuggestions() {
  return new Promise((resolve) => setTimeout(() => resolve(assistantSuggestions), 100))
}

export function askAssistant(question) {
  // Simulated "thinking" latency for a more realistic chat feel
  const delay = 500 + Math.random() * 500
  return new Promise((resolve) => setTimeout(() => resolve(getAssistantReply(question)), delay))
}
