import { ArrowUpRight, ArrowDownRight } from 'lucide-react'

export default function StatCard({ icon, label, value, unit, changePct, meta }) {
  const isUp = typeof changePct === 'number' && changePct >= 0
  return (
    <div className="card stat-card animate-in">
      <div className="stat-card-top">
        <span className="stat-card-icon" aria-hidden="true">{icon}</span>
        {typeof changePct === 'number' && (
          <span className={`badge ${isUp ? 'badge-up' : 'badge-down'}`}>
            {isUp ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}
            {Math.abs(changePct)}%
          </span>
        )}
      </div>
      <div className="stat-card-label">{label}</div>
      <div className="stat-card-value mono">
        {value}
        {unit && <span className="unit">{unit}</span>}
      </div>
      {meta && <div className="stat-card-meta">{meta}</div>}
    </div>
  )
}
