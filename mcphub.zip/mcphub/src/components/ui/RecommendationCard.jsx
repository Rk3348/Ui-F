import { Sparkles } from 'lucide-react'
import { crops } from '../../data/mockData'

export default function RecommendationCard({ recommendation }) {
  if (!recommendation) return null
  const crop = crops.find((c) => c.id === recommendation.cropId)

  return (
    <div className="card recommendation-card animate-in">
      <div className="recommendation-eyebrow">
        <Sparkles size={13} />
        AI Recommendation {crop ? `· ${crop.name}` : ''}
      </div>
      <h3 className="recommendation-headline">{recommendation.headline}</h3>
      <p className="recommendation-detail">{recommendation.detail}</p>
      <div className="recommendation-confidence">
        <span>Confidence</span>
        <div className="confidence-track">
          <div className="confidence-fill" style={{ width: `${recommendation.confidence}%` }} />
        </div>
        <span>{recommendation.confidence}%</span>
      </div>
    </div>
  )
}
