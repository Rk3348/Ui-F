import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts'

function ChartTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null
  return (
    <div
      style={{
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: 10,
        padding: '8px 12px',
        boxShadow: 'var(--shadow-md)',
        fontSize: 12,
      }}
    >
      <div style={{ color: 'var(--ink-muted)', marginBottom: 4 }}>{label}</div>
      {payload.map((p) => (
        <div key={p.dataKey} style={{ fontWeight: 700, fontFamily: 'var(--font-mono)', color: p.color }}>
          ₹{p.value?.toLocaleString('en-IN')} <span style={{ color: 'var(--ink-muted)', fontWeight: 500 }}>{p.name}</span>
        </div>
      ))}
    </div>
  )
}

/**
 * Merges a historical series and a forecast series into one dataset with
 * `actual` and `forecast` keys so both render as continuous connected lines.
 */
export default function PredictionChart({ historical, forecast, height = 280 }) {
  const merged = [
    ...historical.map((d) => ({ date: d.date, actual: d.price, forecast: null })),
    ...forecast.map((d, i) => ({
      date: d.date,
      actual: i === 0 ? historical[historical.length - 1]?.price ?? null : null,
      forecast: d.price,
    })),
  ]
  // Bridge the gap so the forecast line starts exactly where actual ends
  if (merged.length > historical.length) {
    merged[historical.length - 1].forecast = merged[historical.length - 1].actual
  }

  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={merged} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
        <CartesianGrid stroke="var(--border)" vertical={false} />
        <XAxis
          dataKey="date"
          tick={{ fontSize: 11, fill: 'var(--ink-faint)' }}
          tickLine={false}
          axisLine={{ stroke: 'var(--border)' }}
          minTickGap={20}
        />
        <YAxis
          tick={{ fontSize: 11, fill: 'var(--ink-faint)' }}
          tickLine={false}
          axisLine={false}
          width={56}
          tickFormatter={(v) => `₹${Math.round(v / 100) / 10}k`}
          domain={['auto', 'auto']}
        />
        <Tooltip content={<ChartTooltip />} />
        <Legend
          verticalAlign="top"
          height={28}
          iconType="plainline"
          wrapperStyle={{ fontSize: 12, color: 'var(--ink-muted)' }}
        />
        <Line
          type="monotone"
          dataKey="actual"
          name="Historical"
          stroke="var(--primary)"
          strokeWidth={2.5}
          dot={false}
          connectNulls={false}
        />
        <Line
          type="monotone"
          dataKey="forecast"
          name="AI forecast"
          stroke="var(--accent)"
          strokeWidth={2.5}
          strokeDasharray="6 5"
          dot={false}
          connectNulls
        />
      </LineChart>
    </ResponsiveContainer>
  )
}
