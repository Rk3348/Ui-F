export default function CropCard({ crop, price, onClick }) {
  const isUp = price?.changePct >= 0
  return (
    <button className="card crop-card animate-in" onClick={onClick} type="button">
      <div className="crop-card-icon" aria-hidden="true">{crop.icon}</div>
      <div className="crop-card-body">
        <div className="crop-card-name">{crop.name}</div>
        <div className="crop-card-sub">per {crop.unit}</div>
      </div>
      {price && (
        <div className="crop-card-price">
          <div className="amount mono">₹{price.current.toLocaleString('en-IN')}</div>
          <span className={`badge ${isUp ? 'badge-up' : 'badge-down'}`} style={{ marginTop: 4 }}>
            {isUp ? '▲' : '▼'} {Math.abs(price.changePct)}%
          </span>
        </div>
      )}
    </button>
  )
}
