import { crops, markets, currentPrices } from '../../data/mockData'

export default function MandiTicker() {
  const items = crops.map((crop) => {
    const rows = markets.map((m) => currentPrices[crop.id][m.id])
    const avg = Math.round(rows.reduce((sum, r) => sum + r.current, 0) / rows.length)
    const change = rows[0].changePct
    return { crop, avg, change }
  })
  const loop = [...items, ...items]

  return (
    <div className="ticker" role="marquee" aria-label="Live mandi price ticker">
      <div className="ticker-track">
        {loop.map((item, i) => (
          <div className="ticker-item" key={`${item.crop.id}-${i}`}>
            <span className="t-icon" aria-hidden="true">{item.crop.icon}</span>
            <span className="t-name">{item.crop.name}</span>
            <span>₹{item.avg.toLocaleString('en-IN')}</span>
            <span className={`t-change ${item.change >= 0 ? 'up' : 'down'}`}>
              {item.change >= 0 ? '▲' : '▼'} {Math.abs(item.change)}%
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}
