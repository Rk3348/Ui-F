export default function EmptyState({ icon = '🌱', title, message }) {
  return (
    <div className="empty-state">
      <div className="e-icon" aria-hidden="true">{icon}</div>
      <div className="e-title">{title}</div>
      {message && <p style={{ fontSize: 13 }}>{message}</p>}
    </div>
  )
}
