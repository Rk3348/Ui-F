export default function MarketCard({ row }) {
  const { market, price, demand, arrivalQuintals, distanceKm, priceDiffPct, recommended } = row
  return (
    <div className={`market-row ${recommended ? 'recommended' : ''}`}>
      <div className="market-name-cell">
        <span className="m-name">
          {market.name} {recommended && <span className="badge badge-accent" style={{ marginLeft: 6 }}>Best pick</span>}
        </span>
        <span className="m-state">{market.state}</span>
      </div>
      <div className="mono" style={{ fontWeight: 700 }}>₹{price.toLocaleString('en-IN')}</div>
      <div>
        <span className={`badge ${demand === 'High' ? 'badge-up' : demand === 'Low' ? 'badge-down' : 'badge-neutral'}`}>
          {demand}
        </span>
      </div>
      <div className="mono">{arrivalQuintals.toLocaleString('en-IN')} qtl</div>
      <div className="mono">{distanceKm} km</div>
      <div className={`mono ${priceDiffPct === 0 ? '' : priceDiffPct > -3 ? 'text-up' : 'text-down'}`}>
        {priceDiffPct === 0 ? '—' : `${priceDiffPct}%`}
      </div>
    </div>
  )
}
