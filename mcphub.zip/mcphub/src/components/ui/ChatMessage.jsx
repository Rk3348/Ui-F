function renderContent(text) {
  // Very small markdown-ish bold parser: **bold**
  const parts = text.split(/(\*\*[^*]+\*\*)/g)
  return parts.map((part, i) =>
    part.startsWith('**') && part.endsWith('**') ? (
      <strong key={i}>{part.slice(2, -2)}</strong>
    ) : (
      <span key={i}>{part}</span>
    )
  )
}

export default function ChatMessage({ role, content, time, typing = false }) {
  const isUser = role === 'user'
  return (
    <div className={`chat-message ${isUser ? 'user' : 'assistant'}`}>
      <div className="chat-message-avatar" aria-hidden="true">{isUser ? '🧑‍🌾' : '🤖'}</div>
      <div>
        <div className="chat-bubble">
          {typing ? (
            <div className="typing-indicator" aria-label="AI is typing">
              <span /><span /><span />
            </div>
          ) : (
            renderContent(content)
          )}
        </div>
        {time && !typing && <span className="chat-message-time">{time}</span>}
      </div>
    </div>
  )
}
