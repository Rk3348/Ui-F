const conditionIcons = {
  Sunny: '☀️',
  'Partly Cloudy': '⛅',
  Cloudy: '☁️',
  'Light Rain': '🌦️',
  Thunderstorm: '⛈️',
}

export default function WeatherCard({ weather, compact = false }) {
  if (!weather) return null
  const icon = conditionIcons[weather.condition] ?? '🌤️'

  return (
    <div className="card">
      <div className="weather-hero">
        <div>
          <div className="stat-card-label">{weather.location}</div>
          <div className="weather-hero-temp">
            {weather.temperatureC}
            <span className="deg">°C</span>
          </div>
          <div className="text-muted" style={{ fontSize: 13, marginTop: 4 }}>{weather.condition}</div>
        </div>
        <div className="weather-condition-icon" aria-hidden="true">{icon}</div>
      </div>

      {!compact && (
        <>
          <div className="weather-metrics">
            <div className="weather-metric">
              <div className="w-label">Humidity</div>
              <div className="w-value">{weather.humidity}%</div>
            </div>
            <div className="weather-metric">
              <div className="w-label">Rain chance</div>
              <div className="w-value">{weather.rainProbability}%</div>
            </div>
            <div className="weather-metric">
              <div className="w-label">Wind</div>
              <div className="w-value">{weather.windKph} km/h</div>
            </div>
          </div>
          {weather.advisory && (
            <p className="text-muted" style={{ fontSize: 12.5, marginTop: 16 }}>
              🌾 {weather.advisory}
            </p>
          )}
        </>
      )}
    </div>
  )
}
