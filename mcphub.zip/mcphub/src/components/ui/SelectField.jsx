export default function SelectField({ label, value, onChange, options, id }) {
  const fieldId = id ?? `field-${label?.replace(/\s+/g, '-').toLowerCase()}`
  return (
    <div className="field">
      <label htmlFor={fieldId}>{label}</label>
      <select id={fieldId} className="select-field" value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  )
}
