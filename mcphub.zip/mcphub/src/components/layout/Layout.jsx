import { useState } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import Sidebar from './Sidebar'
import Header from './Header'
import { useLanguage } from '../../context/LanguageContext'

const routeTitleKeys = {
  '/': 'nav_dashboard',
  '/market-prices': 'nav_marketPrices',
  '/prediction': 'nav_prediction',
  '/comparison': 'nav_comparison',
  '/weather': 'nav_weather',
  '/assistant': 'nav_assistant',
  '/history': 'nav_history',
  '/notifications': 'nav_notifications',
  '/profile': 'nav_profile',
  '/settings': 'nav_settings',
}

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { t } = useLanguage()
  const location = useLocation()
  const titleKey = routeTitleKeys[location.pathname] ?? 'nav_dashboard'

  return (
    <div className="app-shell">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="main-column">
        <Header title={t(titleKey)} onMenuClick={() => setSidebarOpen(true)} />
        <main className="content-area">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
