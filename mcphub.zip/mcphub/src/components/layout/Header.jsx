import { useNavigate } from 'react-router-dom'
import { Search, Bell, Sun, Moon, Menu } from 'lucide-react'
import { useTheme } from '../../context/ThemeContext'
import { currentUser, notifications } from '../../data/mockData'

export default function Header({ title, onMenuClick }) {
  const { theme, toggleTheme } = useTheme()
  const navigate = useNavigate()
  const unreadCount = notifications.filter((n) => !n.read).length
  const initials = currentUser.name
    .split(' ')
    .map((p) => p[0])
    .join('')
    .slice(0, 2)

  return (
    <>
      <header className="app-header">
        <div className="header-search">
          <Search />
          <input type="text" placeholder="Search crops, markets, mandis..." aria-label="Search" />
        </div>

        <div className="header-actions">
          <button className="icon-btn" onClick={toggleTheme} aria-label="Toggle dark mode">
            {theme === 'dark' ? <Sun /> : <Moon />}
          </button>
          <button className="icon-btn" onClick={() => navigate('/notifications')} aria-label="Notifications">
            <Bell />
            {unreadCount > 0 && <span className="dot" />}
          </button>
          <button className="header-profile" onClick={() => navigate('/profile')}>
            <div className="avatar">{initials}</div>
            <div>
              <div className="h-name">{currentUser.name}</div>
              <div className="h-role">{currentUser.location.split(',')[0]}</div>
            </div>
          </button>
        </div>
      </header>

      <div className="mobile-topbar">
        <button className="icon-btn" onClick={onMenuClick} aria-label="Open menu">
          <Menu />
        </button>
        <strong>{title}</strong>
        <button className="icon-btn" onClick={() => navigate('/notifications')} aria-label="Notifications">
          <Bell />
          {unreadCount > 0 && <span className="dot" />}
        </button>
      </div>
    </>
  )
}
