import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard,
  LineChart,
  TrendingUp,
  GitCompare,
  CloudSun,
  Bot,
  History,
  Bell,
  User,
  Settings,
  X,
} from 'lucide-react'
import { useLanguage } from '../../context/LanguageContext'
import { currentUser } from '../../data/mockData'

const navItems = [
  { to: '/', key: 'nav_dashboard', icon: LayoutDashboard, end: true },
  { to: '/market-prices', key: 'nav_marketPrices', icon: LineChart },
  { to: '/prediction', key: 'nav_prediction', icon: TrendingUp },
  { to: '/comparison', key: 'nav_comparison', icon: GitCompare },
  { to: '/weather', key: 'nav_weather', icon: CloudSun },
  { to: '/assistant', key: 'nav_assistant', icon: Bot },
  { to: '/history', key: 'nav_history', icon: History },
  { to: '/notifications', key: 'nav_notifications', icon: Bell },
  { to: '/profile', key: 'nav_profile', icon: User },
  { to: '/settings', key: 'nav_settings', icon: Settings },
]

export default function Sidebar({ open, onClose }) {
  const { t } = useLanguage()
  const initials = currentUser.name
    .split(' ')
    .map((p) => p[0])
    .join('')
    .slice(0, 2)

  return (
    <>
      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <div className="sidebar-brand">
          <div className="sidebar-brand-mark" aria-hidden="true">M</div>
          <div className="sidebar-brand-text">
            <div className="name">MCPHub</div>
            <div className="tagline">Crop &amp; Market Intelligence</div>
          </div>
          <button className="icon-btn mobile-only-close" onClick={onClose} aria-label="Close menu"
            style={{ marginLeft: 'auto', display: open ? 'flex' : 'none' }}>
            <X />
          </button>
        </div>

        <nav className="sidebar-nav" aria-label="Primary">
          {navItems.map(({ to, key, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              onClick={onClose}
              className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
            >
              <Icon />
              <span>{t(key)}</span>
            </NavLink>
          ))}
        </nav>

        <div className="sidebar-footer">
          <NavLink to="/profile" className="sidebar-user" onClick={onClose}>
            <div className="sidebar-avatar">{initials}</div>
            <div>
              <div className="u-name">{currentUser.name}</div>
              <div className="u-role">{currentUser.role}</div>
            </div>
          </NavLink>
        </div>
      </aside>
      <div className={`sidebar-scrim ${open ? 'open' : ''}`} onClick={onClose} />
    </>
  )
}
