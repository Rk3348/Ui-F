import { Routes, Route } from 'react-router-dom'
import Layout from './components/layout/Layout'
import Dashboard from './pages/Dashboard'
import MarketPrices from './pages/MarketPrices'
import Prediction from './pages/Prediction'
import MarketComparison from './pages/MarketComparison'
import Weather from './pages/Weather'
import Assistant from './pages/Assistant'
import History from './pages/History'
import Notifications from './pages/Notifications'
import Profile from './pages/Profile'
import Settings from './pages/Settings'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/market-prices" element={<MarketPrices />} />
        <Route path="/prediction" element={<Prediction />} />
        <Route path="/comparison" element={<MarketComparison />} />
        <Route path="/weather" element={<Weather />} />
        <Route path="/assistant" element={<Assistant />} />
        <Route path="/history" element={<History />} />
        <Route path="/notifications" element={<Notifications />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="*" element={<Dashboard />} />
      </Route>
    </Routes>
  )
}
