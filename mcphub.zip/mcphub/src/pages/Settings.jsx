import { useState } from 'react'
import { useTheme } from '../context/ThemeContext'
import { useLanguage, supportedLanguages } from '../context/LanguageContext'

export default function Settings() {
  const { theme, setTheme } = useTheme()
  const { language, setLanguage, t } = useLanguage()
  const [notifPrefs, setNotifPrefs] = useState({
    priceAlerts: true,
    predictions: true,
    weather: true,
    marketing: false,
  })
  const [units, setUnits] = useState('quintal')
  const [saved, setSaved] = useState(false)

  function toggleNotif(key) {
    setNotifPrefs((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  function handleSave() {
    setSaved(true)
    setTimeout(() => setSaved(false), 2200)
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="eyebrow">Make it yours</span>
          <h1>Settings</h1>
          <p className="page-subtitle">Language, appearance, notifications and measurement units.</p>
        </div>
      </div>

      <div className="section">
        <div className="section-title"><h2>Language</h2></div>
        <div className="card">
          <div className="settings-row">
            <div>
              <div className="settings-row-label">Interface language</div>
              <div className="settings-row-desc">MCPHub is being localised for English, Hindi and Marathi. English is complete; Hindi and Marathi cover navigation for now.</div>
            </div>
            <div className="settings-group">
              {supportedLanguages.map((l) => (
                <button
                  key={l.code}
                  className={`chip-option ${language === l.code ? 'active' : ''}`}
                  onClick={() => setLanguage(l.code)}
                  type="button"
                >
                  {l.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="section">
        <div className="section-title"><h2>Appearance</h2></div>
        <div className="card">
          <div className="settings-row">
            <div>
              <div className="settings-row-label">Theme</div>
              <div className="settings-row-desc">Switch between light and dark mode. Your choice is applied instantly across MCPHub.</div>
            </div>
            <div className="settings-group">
              <button
                className={`chip-option ${theme === 'light' ? 'active' : ''}`}
                onClick={() => setTheme('light')}
                type="button"
              >
                ☀️ Light
              </button>
              <button
                className={`chip-option ${theme === 'dark' ? 'active' : ''}`}
                onClick={() => setTheme('dark')}
                type="button"
              >
                🌙 Dark
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="section">
        <div className="section-title"><h2>Notifications</h2></div>
        <div className="card">
          <div className="settings-row">
            <div>
              <div className="settings-row-label">Price alerts</div>
              <div className="settings-row-desc">Get notified when prices move sharply for your tracked crops.</div>
            </div>
            <label className="toggle">
              <input type="checkbox" checked={notifPrefs.priceAlerts} onChange={() => toggleNotif('priceAlerts')} />
              <span className="toggle-track"><span className="toggle-thumb" /></span>
            </label>
          </div>
          <div className="settings-row">
            <div>
              <div className="settings-row-label">Prediction updates</div>
              <div className="settings-row-desc">Get notified when a new 7-day prediction is ready.</div>
            </div>
            <label className="toggle">
              <input type="checkbox" checked={notifPrefs.predictions} onChange={() => toggleNotif('predictions')} />
              <span className="toggle-track"><span className="toggle-thumb" /></span>
            </label>
          </div>
          <div className="settings-row">
            <div>
              <div className="settings-row-label">Weather alerts</div>
              <div className="settings-row-desc">Get notified about rain or extreme weather that could affect harvesting.</div>
            </div>
            <label className="toggle">
              <input type="checkbox" checked={notifPrefs.weather} onChange={() => toggleNotif('weather')} />
              <span className="toggle-track"><span className="toggle-thumb" /></span>
            </label>
          </div>
          <div className="settings-row">
            <div>
              <div className="settings-row-label">Product news</div>
              <div className="settings-row-desc">Occasional updates about new MCPHub features.</div>
            </div>
            <label className="toggle">
              <input type="checkbox" checked={notifPrefs.marketing} onChange={() => toggleNotif('marketing')} />
              <span className="toggle-track"><span className="toggle-thumb" /></span>
            </label>
          </div>
        </div>
      </div>

      <div className="section">
        <div className="section-title"><h2>Units</h2></div>
        <div className="card">
          <div className="settings-row">
            <div>
              <div className="settings-row-label">Price &amp; quantity units</div>
              <div className="settings-row-desc">Choose how prices and arrival quantities are displayed.</div>
            </div>
            <div className="settings-group">
              <button className={`chip-option ${units === 'quintal' ? 'active' : ''}`} onClick={() => setUnits('quintal')} type="button">Per quintal</button>
              <button className={`chip-option ${units === 'kg' ? 'active' : ''}`} onClick={() => setUnits('kg')} type="button">Per kg</button>
              <button className={`chip-option ${units === 'tonne' ? 'active' : ''}`} onClick={() => setUnits('tonne')} type="button">Per tonne</button>
            </div>
          </div>
        </div>
      </div>

      <div className="section" style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button className="btn btn-primary" onClick={handleSave} type="button">{t('action_save')}</button>
        {saved && <span className="text-up" style={{ fontSize: 13, fontWeight: 600 }}>✓ Preferences saved</span>}
      </div>
    </div>
  )
}
