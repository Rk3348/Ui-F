import { useEffect, useState } from 'react'
import { TrendingUp, CloudSun, Sparkles, Bell as BellIcon, Info } from 'lucide-react'
import EmptyState from '../components/ui/EmptyState'
import Skeleton from '../components/ui/Skeleton'
import { fetchNotifications } from '../services/userDataService'

const iconByType = {
  'price-alert': <TrendingUp size={17} color="var(--primary)" />,
  prediction: <Sparkles size={17} color="var(--accent-dark)" />,
  weather: <CloudSun size={17} color="var(--primary)" />,
  recommendation: <Sparkles size={17} color="var(--accent-dark)" />,
  system: <Info size={17} color="var(--ink-muted)" />,
}

export default function Notifications() {
  const [items, setItems] = useState(null)

  useEffect(() => {
    fetchNotifications().then(setItems)
  }, [])

  function markAllRead() {
    setItems((prev) => prev.map((n) => ({ ...n, read: true })))
  }

  const unreadCount = items?.filter((n) => !n.read).length ?? 0

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="eyebrow">Stay in the loop</span>
          <h1>Notifications</h1>
          <p className="page-subtitle">Price alerts, predictions and weather updates for your tracked crops.</p>
        </div>
        {unreadCount > 0 && (
          <button className="btn btn-ghost btn-sm" onClick={markAllRead}>
            Mark all as read
          </button>
        )}
      </div>

      <div className="card" style={{ padding: 'var(--space-2) var(--space-3)' }}>
        {!items && <Skeleton height={280} />}
        {items && items.length === 0 && (
          <EmptyState icon={<BellIcon />} title="You're all caught up" message="New alerts will show up here." />
        )}
        {items?.map((n) => (
          <div key={n.id} className={`notification-item ${!n.read ? 'unread' : ''}`}>
            <div className="notification-icon" aria-hidden="true">{iconByType[n.type] ?? <BellIcon size={17} />}</div>
            <div className="notification-body">
              <div className="notification-title">{n.title}</div>
              <div className="notification-message">{n.message}</div>
              <div className="notification-time">{n.time}</div>
            </div>
            {!n.read && <span className="unread-dot" aria-label="Unread" />}
          </div>
        ))}
      </div>
    </div>
  )
}
