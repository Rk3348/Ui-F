import { useEffect, useRef, useState } from 'react'
import { Send } from 'lucide-react'
import ChatMessage from '../components/ui/ChatMessage'
import { assistantSuggestions } from '../data/mockData'
import { askAssistant } from '../services/assistantService'

const WELCOME = {
  role: 'assistant',
  content:
    "Namaste! I'm the MCPHub AI Assistant. Ask me about crop prices, market comparisons, or predictions — I'm currently answering from mock data.",
  time: 'Just now',
}

function timeNow() {
  return new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
}

export default function Assistant() {
  const [messages, setMessages] = useState([WELCOME])
  const [input, setInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const scrollRef = useRef(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages, isTyping])

  async function handleSend(text) {
    const question = (text ?? input).trim()
    if (!question) return
    setMessages((prev) => [...prev, { role: 'user', content: question, time: timeNow() }])
    setInput('')
    setIsTyping(true)
    const reply = await askAssistant(question)
    setIsTyping(false)
    setMessages((prev) => [...prev, { role: 'assistant', content: reply, time: timeNow() }])
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="eyebrow">Ask anything about your crops</span>
          <h1>AI Assistant</h1>
          <p className="page-subtitle">A conversational shortcut to prices, predictions and recommendations.</p>
        </div>
      </div>

      <div className="assistant-shell">
        <div className="assistant-header">
          <div className="assistant-avatar" aria-hidden="true">🤖</div>
          <div>
            <div className="a-name">MCPHub Assistant</div>
            <div className="a-status"><span className="dot" /> Online · mock responses</div>
          </div>
        </div>

        <div className="assistant-messages" ref={scrollRef}>
          {messages.map((m, i) => (
            <ChatMessage key={i} role={m.role} content={m.content} time={m.time} />
          ))}
          {isTyping && <ChatMessage role="assistant" typing />}
        </div>

        <div className="chat-suggestions">
          {assistantSuggestions.map((s) => (
            <button key={s} className="chat-suggestion-chip" onClick={() => handleSend(s)}>
              {s}
            </button>
          ))}
        </div>

        <form
          className="assistant-input-row"
          onSubmit={(e) => {
            e.preventDefault()
            handleSend()
          }}
        >
          <input
            type="text"
            placeholder="Ask about a crop, market, or prediction..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            aria-label="Message MCPHub Assistant"
          />
          <button type="submit" className="send-btn" disabled={!input.trim()} aria-label="Send message">
            <Send size={18} />
          </button>
        </form>
      </div>
    </div>
  )
}
