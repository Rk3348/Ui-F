import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Wallet, TrendingUp, MapPinned, Sprout } from 'lucide-react'
import StatCard from '../components/ui/StatCard'
import CropCard from '../components/ui/CropCard'
import PredictionChart from '../components/ui/PredictionChart'
import WeatherCard from '../components/ui/WeatherCard'
import RecommendationCard from '../components/ui/RecommendationCard'
import MandiTicker from '../components/ui/MandiTicker'
import Skeleton from '../components/ui/Skeleton'
import { crops, markets, currentPrices } from '../data/mockData'
import { fetchHistoricalSeries } from '../services/cropService'
import { fetchPrediction, fetchRecommendation, fetchBestMarketSuggestion } from '../services/predictionService'
import { fetchWeatherToday } from '../services/weatherService'
import { fetchRecentlyAnalyzed } from '../services/userDataService'

const HERO_CROP = 'onion'
const HERO_MARKET = 'nashik'

export default function Dashboard() {
  const navigate = useNavigate()
  const [prediction, setPrediction] = useState(null)
  const [historical, setHistorical] = useState(null)
  const [weather, setWeather] = useState(null)
  const [recommendation, setRecommendation] = useState(null)
  const [bestMarket, setBestMarket] = useState(null)
  const [recent, setRecent] = useState(null)

  useEffect(() => {
    fetchPrediction(HERO_CROP, HERO_MARKET).then(setPrediction)
    fetchHistoricalSeries(HERO_CROP, HERO_MARKET, 10).then(setHistorical)
    fetchWeatherToday().then(setWeather)
    fetchRecommendation().then(setRecommendation)
    fetchBestMarketSuggestion('onion').then(setBestMarket)
    fetchRecentlyAnalyzed().then(setRecent)
  }, [])

  const overviewRows = markets.slice(0, 3).map((m) => ({
    market: m,
    price: currentPrices.onion[m.id],
  }))

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="eyebrow">Welcome back</span>
          <h1>Today's market snapshot</h1>
          <p className="page-subtitle">Live prices, AI predictions and recommendations across your tracked crops.</p>
        </div>
      </div>

      <MandiTicker />

      <div className="section grid grid-cols-4">
        <StatCard
          icon={<Wallet size={19} color="var(--primary)" />}
          label="Onion — Nashik"
          value={`₹${currentPrices.onion.nashik.current.toLocaleString('en-IN')}`}
          changePct={currentPrices.onion.nashik.changePct}
          meta="per quintal, updated 7:30 AM"
        />
        <StatCard
          icon={<TrendingUp size={19} color="var(--primary)" />}
          label="7-day forecast confidence"
          value={prediction ? `${prediction.confidence}%` : '—'}
          meta="AI model, mock ensemble"
        />
        <StatCard
          icon={<MapPinned size={19} color="var(--primary)" />}
          label="Best market today"
          value={bestMarket ? bestMarket.best.market.name.split(' ')[0] : '—'}
          meta={bestMarket ? `+${bestMarket.netGainPct}% vs nearest mandi` : ''}
        />
        <StatCard
          icon={<Sprout size={19} color="var(--primary)" />}
          label="Crops tracked"
          value={crops.length}
          meta="Onion · Wheat · Rice · Tomato · Potato"
        />
      </div>

      <div className="grid grid-cols-3" style={{ gridTemplateColumns: '2fr 1fr', alignItems: 'start' }}>
        <div className="section" style={{ marginBottom: 0 }}>
          <div className="section-title">
            <h2>Onion · 7-day price prediction</h2>
            <button className="link-btn" onClick={() => navigate('/prediction')}>Full prediction →</button>
          </div>
          <div className="card">
            {prediction && historical ? (
              <PredictionChart historical={historical} forecast={prediction.next7} height={280} />
            ) : (
              <Skeleton height={280} />
            )}
          </div>
        </div>

        <div className="section" style={{ marginBottom: 0 }}>
          <div className="section-title">
            <h2>Weather</h2>
            <button className="link-btn" onClick={() => navigate('/weather')}>Details →</button>
          </div>
          {weather ? <WeatherCard weather={weather} compact /> : <Skeleton height={280} />}
        </div>
      </div>

      <div className="section" style={{ marginTop: 'var(--space-8)' }}>
        <div className="section-title">
          <h2>AI recommendation</h2>
        </div>
        {recommendation ? <RecommendationCard recommendation={recommendation} /> : <Skeleton height={140} />}
      </div>

      <div className="grid grid-cols-3" style={{ gridTemplateColumns: '1.4fr 1fr' }}>
        <div className="section" style={{ marginBottom: 0 }}>
          <div className="section-title">
            <h2>Market overview — Onion</h2>
            <button className="link-btn" onClick={() => navigate('/market-prices')}>{'View all →'}</button>
          </div>
          <div className="grid grid-cols-3">
            {overviewRows.map(({ market, price }) => (
              <div className="card" key={market.id}>
                <div className="stat-card-label">{market.name}</div>
                <div className="stat-card-value mono" style={{ fontSize: 22, marginTop: 6 }}>
                  ₹{price.current.toLocaleString('en-IN')}
                </div>
                <span className={`badge ${price.changePct >= 0 ? 'badge-up' : 'badge-down'}`} style={{ marginTop: 8 }}>
                  {price.changePct >= 0 ? '▲' : '▼'} {Math.abs(price.changePct)}%
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="section" style={{ marginBottom: 0 }}>
          <div className="section-title">
            <h2>Recently analyzed</h2>
            <button className="link-btn" onClick={() => navigate('/history')}>View all →</button>
          </div>
          <div className="card">
            {recent
              ? recent.map((item, i) => {
                  const crop = crops.find((c) => c.id === item.cropId)
                  const market = markets.find((m) => m.id === item.marketId)
                  return (
                    <div className="recent-item" key={i}>
                      <div className="recent-item-icon" aria-hidden="true">{crop.icon}</div>
                      <div className="recent-item-body">
                        <div className="recent-item-title">{crop.name} · {market.name}</div>
                        <div className="recent-item-sub">{item.analyzedAt}</div>
                      </div>
                      <span className={`badge ${item.recommendation === 'Sell' ? 'badge-accent' : 'badge-up'}`}>
                        {item.recommendation}
                      </span>
                    </div>
                  )
                })
              : <Skeleton height={200} />}
          </div>
        </div>
      </div>

      <div className="section">
        <div className="section-title">
          <h2>Your tracked crops</h2>
        </div>
        <div className="grid grid-cols-4">
          {crops.map((crop) => (
            <CropCard
              key={crop.id}
              crop={crop}
              price={currentPrices[crop.id].pune}
              onClick={() => navigate('/market-prices')}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
