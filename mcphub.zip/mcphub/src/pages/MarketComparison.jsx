import { useEffect, useState } from 'react'
import SelectField from '../components/ui/SelectField'
import MarketCard from '../components/ui/MarketCard'
import Skeleton from '../components/ui/Skeleton'
import { crops } from '../data/mockData'
import { fetchMarketComparison } from '../services/cropService'

export default function MarketComparison() {
  const [cropId, setCropId] = useState('onion')
  const [rows, setRows] = useState(null)

  useEffect(() => {
    setRows(null)
    fetchMarketComparison(cropId).then(setRows)
  }, [cropId])

  const crop = crops.find((c) => c.id === cropId)
  const recommended = rows?.find((r) => r.recommended)

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="eyebrow">Sell where it pays best</span>
          <h1>Market comparison</h1>
          <p className="page-subtitle">Compare prices, demand and distance across markets to find the best place to sell.</p>
        </div>
      </div>

      <div className="selector-row">
        <SelectField
          label="Crop"
          value={cropId}
          onChange={setCropId}
          options={crops.map((c) => ({ value: c.id, label: `${c.icon} ${c.name}` }))}
        />
      </div>

      {recommended && (
        <div className="section">
          <div className="card recommendation-card">
            <div className="recommendation-eyebrow">Recommended market</div>
            <h3 className="recommendation-headline">
              Sell {crop.name.toLowerCase()} at {recommended.market.name}
            </h3>
            <p className="recommendation-detail">
              Currently offering ₹{recommended.price.toLocaleString('en-IN')}/quintal — the highest among your
              tracked markets, {recommended.distanceKm} km away with {recommended.demand.toLowerCase()} demand.
            </p>
          </div>
        </div>
      )}

      <div className="section">
        <div className="section-title">
          <h2>{crop.icon} {crop.name} — all markets</h2>
        </div>
        <div className="card" style={{ padding: 'var(--space-2) var(--space-5)' }}>
          <div className="market-row head">
            <div>Market</div>
            <div>Price</div>
            <div>Demand</div>
            <div>Arrivals</div>
            <div>Distance</div>
            <div>vs. best</div>
          </div>
          {rows ? (
            rows
              .slice()
              .sort((a, b) => b.price - a.price)
              .map((row) => <MarketCard key={row.market.id} row={row} />)
          ) : (
            <Skeleton height={220} />
          )}
        </div>
      </div>
    </div>
  )
}
