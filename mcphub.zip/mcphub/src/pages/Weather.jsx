import { useEffect, useState } from 'react'
import WeatherCard from '../components/ui/WeatherCard'
import Skeleton from '../components/ui/Skeleton'
import { fetchWeatherToday, fetchWeatherForecast } from '../services/weatherService'

const conditionIcons = {
  Sunny: '☀️',
  'Partly Cloudy': '⛅',
  Cloudy: '☁️',
  'Light Rain': '🌦️',
  Thunderstorm: '⛈️',
}

export default function Weather() {
  const [today, setToday] = useState(null)
  const [forecast, setForecast] = useState(null)

  useEffect(() => {
    fetchWeatherToday().then(setToday)
    fetchWeatherForecast().then(setForecast)
  }, [])

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="eyebrow">Plan around the sky</span>
          <h1>Weather intelligence</h1>
          <p className="page-subtitle">Localised forecasts to help you time harvesting, spraying and transport.</p>
        </div>
      </div>

      <div className="section">
        {today ? <WeatherCard weather={today} /> : <Skeleton height={220} />}
      </div>

      <div className="section">
        <div className="section-title">
          <h2>7-day forecast</h2>
        </div>
        <div className="card">
          {forecast ? (
            <div className="forecast-strip">
              {forecast.map((day) => (
                <div className="forecast-day" key={day.date}>
                  <div className="f-day">{day.day}</div>
                  <div className="f-icon" aria-hidden="true">{conditionIcons[day.condition] ?? '🌤️'}</div>
                  <div className="f-high">{day.high}°</div>
                  <div className="f-low">{day.low}°</div>
                  <div className="f-rain">💧 {day.rainProbability}%</div>
                </div>
              ))}
            </div>
          ) : (
            <Skeleton height={160} />
          )}
        </div>
      </div>
    </div>
  )
}
