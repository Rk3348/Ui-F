import { useEffect, useState } from 'react'
import EmptyState from '../components/ui/EmptyState'
import Skeleton from '../components/ui/Skeleton'
import { crops, markets } from '../data/mockData'
import { fetchAnalysisHistory } from '../services/userDataService'

export default function History() {
  const [history, setHistory] = useState(null)

  useEffect(() => {
    fetchAnalysisHistory().then(setHistory)
  }, [])

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="eyebrow">Your past analyses</span>
          <h1>Analysis history</h1>
          <p className="page-subtitle">Every prediction MCPHub has generated for you, in one place.</p>
        </div>
      </div>

      <div className="card">
        {!history && <Skeleton height={280} />}
        {history && history.length === 0 && (
          <EmptyState icon="📊" title="No analyses yet" message="Run a price prediction to see it appear here." />
        )}
        {history && history.length > 0 && (
          <table className="data-table">
            <thead>
              <tr>
                <th>Crop</th>
                <th>Market</th>
                <th>Date</th>
                <th>Predicted price</th>
                <th>Recommendation</th>
              </tr>
            </thead>
            <tbody>
              {history.map((item) => {
                const crop = crops.find((c) => c.id === item.cropId)
                const market = markets.find((m) => m.id === item.marketId)
                return (
                  <tr key={item.id}>
                    <td>
                      <div className="table-crop-cell">
                        <span aria-hidden="true">{crop.icon}</span> {crop.name}
                      </div>
                    </td>
                    <td>{market.name}</td>
                    <td className="mono">{item.date}</td>
                    <td className="mono">₹{item.predictedPrice.toLocaleString('en-IN')}</td>
                    <td>
                      <span className={`badge ${item.recommendation === 'Sell' ? 'badge-accent' : 'badge-up'}`}>
                        {item.recommendation}
                      </span>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
