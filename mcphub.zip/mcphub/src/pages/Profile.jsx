import { useEffect, useState } from 'react'
import { MapPin, Phone, Calendar, Ruler } from 'lucide-react'
import Skeleton from '../components/ui/Skeleton'
import { crops } from '../data/mockData'
import { fetchCurrentUser } from '../services/userDataService'
import { supportedLanguages } from '../context/LanguageContext'

export default function Profile() {
  const [user, setUser] = useState(null)

  useEffect(() => {
    fetchCurrentUser().then(setUser)
  }, [])

  if (!user) {
    return (
      <div>
        <div className="page-header">
          <div>
            <span className="eyebrow">Your account</span>
            <h1>Profile</h1>
          </div>
        </div>
        <Skeleton height={320} />
      </div>
    )
  }

  const initials = user.name.split(' ').map((p) => p[0]).join('').slice(0, 2)
  const languageLabel = supportedLanguages.find((l) => l.code === user.language)?.label ?? 'English'

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="eyebrow">Your account</span>
          <h1>Profile</h1>
          <p className="page-subtitle">Your details help MCPHub personalise prices, predictions and alerts.</p>
        </div>
      </div>

      <div className="profile-header">
        <div className="profile-avatar-lg" aria-hidden="true">{initials}</div>
        <div>
          <h2 className="profile-name">{user.name}</h2>
          <div className="profile-role">{user.role} · Member since {user.memberSince}</div>
        </div>
      </div>

      <div className="grid grid-cols-2">
        <div className="card">
          <div className="section-title">
            <h2 style={{ fontSize: 15 }}>Contact &amp; location</h2>
          </div>
          <div className="info-row">
            <span className="i-label"><MapPin size={14} style={{ verticalAlign: -2, marginRight: 6 }} />Location</span>
            <span className="i-value">{user.location}</span>
          </div>
          <div className="info-row">
            <span className="i-label"><Phone size={14} style={{ verticalAlign: -2, marginRight: 6 }} />Phone</span>
            <span className="i-value">{user.phone}</span>
          </div>
          <div className="info-row">
            <span className="i-label"><Ruler size={14} style={{ verticalAlign: -2, marginRight: 6 }} />Farm size</span>
            <span className="i-value">{user.farmSizeAcres} acres</span>
          </div>
          <div className="info-row">
            <span className="i-label"><Calendar size={14} style={{ verticalAlign: -2, marginRight: 6 }} />Member since</span>
            <span className="i-value">{user.memberSince}</span>
          </div>
        </div>

        <div className="card">
          <div className="section-title">
            <h2 style={{ fontSize: 15 }}>Preferences</h2>
          </div>
          <div className="info-row">
            <span className="i-label">Preferred language</span>
            <span className="i-value">{languageLabel}</span>
          </div>
          <div style={{ marginTop: 'var(--space-3)' }}>
            <span className="i-label" style={{ display: 'block', marginBottom: 8 }}>Preferred crops</span>
            <div>
              {user.preferredCrops.map((id) => {
                const crop = crops.find((c) => c.id === id)
                return (
                  <span className="pref-crop-tag" key={id}>
                    <span aria-hidden="true">{crop.icon}</span> {crop.name}
                  </span>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
