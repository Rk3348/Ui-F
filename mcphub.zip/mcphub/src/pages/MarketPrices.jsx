import { useEffect, useState } from 'react'
import SelectField from '../components/ui/SelectField'
import PriceChart from '../components/ui/PriceChart'
import Skeleton from '../components/ui/Skeleton'
import { crops, markets } from '../data/mockData'
import { fetchCurrentPrice, fetchHistoricalSeries } from '../services/cropService'

export default function MarketPrices() {
  const [cropId, setCropId] = useState('onion')
  const [marketId, setMarketId] = useState('pune')
  const [price, setPrice] = useState(null)
  const [series, setSeries] = useState(null)

  useEffect(() => {
    setPrice(null)
    setSeries(null)
    fetchCurrentPrice(cropId, marketId).then(setPrice)
    fetchHistoricalSeries(cropId, marketId, 30).then(setSeries)
  }, [cropId, marketId])

  const crop = crops.find((c) => c.id === cropId)
  const market = markets.find((m) => m.id === marketId)

  return (
    <div>
      <div className="page-header">
        <div>
          <span className="eyebrow">Live mandi data</span>
          <h1>Market prices</h1>
          <p className="page-subtitle">Check current and historical prices for any crop across tracked markets.</p>
        </div>
      </div>

      <div className="selector-row">
        <SelectField
          label="Crop"
          value={cropId}
          onChange={setCropId}
          options={crops.map((c) => ({ value: c.id, label: `${c.icon} ${c.name}` }))}
        />
        <SelectField
          label="Market"
          value={marketId}
          onChange={setMarketId}
          options={markets.map((m) => ({ value: m.id, label: m.name }))}
        />
      </div>

      <div className="grid grid-cols-4 section">
        {price ? (
          <>
            <div className="card">
              <div className="stat-card-label">Current price</div>
              <div className="stat-card-value mono">₹{price.current.toLocaleString('en-IN')}</div>
              <span className={`badge ${price.changePct >= 0 ? 'badge-up' : 'badge-down'}`} style={{ marginTop: 8 }}>
                {price.changePct >= 0 ? '▲' : '▼'} {Math.abs(price.changePct)}%
              </span>
            </div>
            <div className="card">
              <div className="stat-card-label">Minimum price</div>
              <div className="stat-card-value mono">₹{price.min.toLocaleString('en-IN')}</div>
              <div className="stat-card-meta">Lowest lot today</div>
            </div>
            <div className="card">
              <div className="stat-card-label">Maximum price</div>
              <div className="stat-card-value mono">₹{price.max.toLocaleString('en-IN')}</div>
              <div className="stat-card-meta">Highest lot today</div>
            </div>
            <div className="card">
              <div className="stat-card-label">Modal price</div>
              <div className="stat-card-value mono">₹{price.modal.toLocaleString('en-IN')}</div>
              <div className="stat-card-meta">Most common trade price</div>
            </div>
          </>
        ) : (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} height={110} />)
        )}
      </div>

      <div className="section">
        <div className="section-title">
          <h2>{crop.icon} {crop.name} at {market.name} — 30-day trend</h2>
          {price && (
            <span className={`badge ${price.demand === 'High' ? 'badge-up' : price.demand === 'Low' ? 'badge-down' : 'badge-neutral'}`}>
              {price.demand} demand
            </span>
          )}
        </div>
        <div className="card">
          {series ? <PriceChart data={series} /> : <Skeleton height={260} />}
        </div>
      </div>

      {price && (
        <div className="section">
          <div className="section-title">
            <h2>Market details</h2>
          </div>
          <div className="card">
            <div className="info-row">
              <span className="i-label">Market</span>
              <span className="i-value">{market.name}, {market.state}</span>
            </div>
            <div className="info-row">
              <span className="i-label">Arrival quantity today</span>
              <span className="i-value mono">{price.arrivalQuintals.toLocaleString('en-IN')} quintals</span>
            </div>
            <div className="info-row">
              <span className="i-label">Last updated</span>
              <span className="i-value">{price.updatedAt}</span>
            </div>
            <div className="info-row">
              <span className="i-label">Distance from you</span>
              <span className="i-value">{market.distanceKm} km</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
