import { createContext, useContext, useState } from 'react'

// ---------------------------------------------------------------------
// Translation dictionary. Keys are UI strings used across the app.
// Hindi and Marathi are stubbed with real translations for navigation
// and common actions now; deeper page copy can be filled in the same
// shape later without touching any component.
// ---------------------------------------------------------------------
const translations = {
  en: {
    languageName: 'English',
    nav_dashboard: 'Dashboard',
    nav_marketPrices: 'Market Prices',
    nav_prediction: 'Price Prediction',
    nav_comparison: 'Market Comparison',
    nav_weather: 'Weather Intelligence',
    nav_assistant: 'AI Assistant',
    nav_history: 'Analysis History',
    nav_notifications: 'Notifications',
    nav_profile: 'Profile',
    nav_settings: 'Settings',
    action_viewAll: 'View all',
    action_save: 'Save changes',
    action_send: 'Send',
  },
  hi: {
    languageName: 'हिन्दी',
    nav_dashboard: 'डैशबोर्ड',
    nav_marketPrices: 'बाजार भाव',
    nav_prediction: 'मूल्य पूर्वानुमान',
    nav_comparison: 'बाजार तुलना',
    nav_weather: 'मौसम जानकारी',
    nav_assistant: 'एआई सहायक',
    nav_history: 'विश्लेषण इतिहास',
    nav_notifications: 'सूचनाएं',
    nav_profile: 'प्रोफ़ाइल',
    nav_settings: 'सेटिंग्स',
    action_viewAll: 'सभी देखें',
    action_save: 'सहेजें',
    action_send: 'भेजें',
  },
  mr: {
    languageName: 'मराठी',
    nav_dashboard: 'डॅशबोर्ड',
    nav_marketPrices: 'बाजारभाव',
    nav_prediction: 'किंमत अंदाज',
    nav_comparison: 'बाजार तुलना',
    nav_weather: 'हवामान माहिती',
    nav_assistant: 'एआय सहाय्यक',
    nav_history: 'विश्लेषण इतिहास',
    nav_notifications: 'सूचना',
    nav_profile: 'प्रोफाइल',
    nav_settings: 'सेटिंग्ज',
    action_viewAll: 'सर्व पहा',
    action_save: 'बदल जतन करा',
    action_send: 'पाठवा',
  },
}

export const supportedLanguages = [
  { code: 'en', label: 'English' },
  { code: 'hi', label: 'हिन्दी (Hindi)' },
  { code: 'mr', label: 'मराठी (Marathi)' },
]

const LanguageContext = createContext(null)

export function LanguageProvider({ children }) {
  const [language, setLanguage] = useState('en')

  function t(key) {
    return translations[language]?.[key] ?? translations.en[key] ?? key
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const ctx = useContext(LanguageContext)
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider')
  return ctx
}
