// -----------------------------------------------------------------------
// MCPHub mock data
// -----------------------------------------------------------------------
// Every value here mirrors the shape a future real API/ML/MCP response
// is expected to take. When the backend is ready, only the services in
// src/services/*.js need to change — components and pages should not.
// -----------------------------------------------------------------------

export const crops = [
  { id: 'onion', name: 'Onion', icon: '🧅', unit: 'quintal' },
  { id: 'wheat', name: 'Wheat', icon: '🌾', unit: 'quintal' },
  { id: 'rice', name: 'Rice', icon: '🍚', unit: 'quintal' },
  { id: 'tomato', name: 'Tomato', icon: '🍅', unit: 'quintal' },
  { id: 'potato', name: 'Potato', icon: '🥔', unit: 'quintal' },
]

export const markets = [
  { id: 'pune', name: 'Pune APMC', state: 'Maharashtra', distanceKm: 12 },
  { id: 'nashik', name: 'Nashik Lasalgaon', state: 'Maharashtra', distanceKm: 168 },
  { id: 'solapur', name: 'Solapur Mandi', state: 'Maharashtra', distanceKm: 254 },
  { id: 'indore', name: 'Indore Mandi', state: 'Madhya Pradesh', distanceKm: 590 },
  { id: 'azadpur', name: 'Azadpur Mandi', state: 'Delhi', distanceKm: 1420 },
]

// Base price per crop (₹ per quintal) — used to derive consistent mock series
const basePrices = {
  onion: 1850,
  wheat: 2340,
  rice: 3120,
  tomato: 1420,
  potato: 1180,
}

// Deterministic pseudo-random generator so numbers stay stable across renders
function seededRandom(seed) {
  let value = seed
  return () => {
    value = (value * 9301 + 49297) % 233280
    return value / 233280
  }
}

function buildSeries(seed, base, days, volatility = 0.03) {
  const rand = seededRandom(seed)
  const series = []
  let price = base
  for (let i = 0; i < days; i++) {
    const drift = (rand() - 0.48) * volatility
    price = Math.max(200, price * (1 + drift))
    series.push(Math.round(price))
  }
  return series
}

function dateLabel(offsetDays) {
  const d = new Date()
  d.setDate(d.getDate() + offsetDays)
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })
}

// ---------------------------------------------------------------------
// Current market prices — per crop, per market
// ---------------------------------------------------------------------
export const currentPrices = {}
crops.forEach((crop, ci) => {
  currentPrices[crop.id] = {}
  markets.forEach((market, mi) => {
    const seed = (ci + 1) * 97 + (mi + 1) * 13
    const rand = seededRandom(seed)
    const base = basePrices[crop.id] * (0.9 + rand() * 0.25)
    const modal = Math.round(base)
    const min = Math.round(modal * (0.88 - rand() * 0.05))
    const max = Math.round(modal * (1.1 + rand() * 0.06))
    const changePct = +(((rand() - 0.5) * 8)).toFixed(2)
    currentPrices[crop.id][market.id] = {
      cropId: crop.id,
      marketId: market.id,
      current: modal,
      min,
      max,
      modal,
      changePct,
      arrivalQuintals: Math.round(400 + rand() * 3600),
      demand: changePct > 2 ? 'High' : changePct < -2 ? 'Low' : 'Moderate',
      updatedAt: 'Today, 7:30 AM',
    }
  })
})

// ---------------------------------------------------------------------
// Historical price series (30 days) per crop, per market
// ---------------------------------------------------------------------
export function getHistoricalSeries(cropId, marketId, days = 30) {
  const cropIndex = crops.findIndex((c) => c.id === cropId)
  const marketIndex = markets.findIndex((m) => m.id === marketId)
  const seed = (cropIndex + 1) * 41 + (marketIndex + 1) * 7 + 3
  const base = currentPrices[cropId]?.[marketId]?.modal ?? basePrices[cropId]
  const raw = buildSeries(seed, base * 0.94, days, 0.025)
  return raw.map((price, i) => ({
    date: dateLabel(-(days - 1 - i)),
    price,
  }))
}

// ---------------------------------------------------------------------
// 7-day prediction + 30-day trend
// ---------------------------------------------------------------------
export function getPrediction(cropId, marketId) {
  const cropIndex = crops.findIndex((c) => c.id === cropId)
  const marketIndex = markets.findIndex((m) => m.id === marketId)
  const seed = (cropIndex + 1) * 53 + (marketIndex + 1) * 19 + 5
  const rand = seededRandom(seed)
  const current = currentPrices[cropId]?.[marketId]?.modal ?? basePrices[cropId]
  const trendBias = (rand() - 0.42) * 0.02

  const next7 = []
  let price = current
  for (let i = 1; i <= 7; i++) {
    price = price * (1 + trendBias + (rand() - 0.5) * 0.015)
    next7.push({ date: dateLabel(i), price: Math.round(price) })
  }

  const next30 = []
  price = current
  for (let i = 1; i <= 30; i++) {
    price = price * (1 + trendBias * 0.8 + (rand() - 0.5) * 0.018)
    if (i % 2 === 0) next30.push({ date: dateLabel(i), price: Math.round(price) })
  }

  const sevenDayPrice = next7[6].price
  const direction = sevenDayPrice >= current ? 'up' : 'down'
  const changePct = +(((sevenDayPrice - current) / current) * 100).toFixed(1)
  const confidence = Math.round(68 + rand() * 24)

  return {
    cropId,
    marketId,
    current,
    sevenDayPrice,
    direction,
    changePct,
    confidence,
    next7,
    next30,
    explanation: buildExplanation(cropId, direction, changePct, confidence),
  }
}

function buildExplanation(cropId, direction, changePct, confidence) {
  const crop = crops.find((c) => c.id === cropId)?.name ?? 'This crop'
  const move = direction === 'up' ? 'rise' : 'ease'
  const driver =
    direction === 'up'
      ? 'lower arrivals from key growing belts and steady festive-season demand'
      : 'higher arrivals from neighbouring mandis and easing transport bottlenecks'
  return `${crop} prices are estimated to ${move} by ${Math.abs(changePct)}% over the next 7 days, mainly driven by ${driver}. Model confidence is ${confidence}%, based on a mock ensemble of historical seasonality and arrival-volume patterns.`
}

// ---------------------------------------------------------------------
// AI recommendation for the dashboard
// ---------------------------------------------------------------------
export function getRecommendation() {
  return {
    cropId: 'onion',
    headline: 'Hold onion stock for 3–4 more days',
    detail:
      'Lasalgaon arrivals are trending lower this week while demand stays firm. Prices are likely to firm up 4–6% before the next major arrival wave.',
    confidence: 82,
    action: 'hold',
  }
}

// ---------------------------------------------------------------------
// Best market suggestion
// ---------------------------------------------------------------------
export function getBestMarketSuggestion(cropId = 'onion') {
  const rows = markets.map((m) => ({
    market: m,
    price: currentPrices[cropId][m.id].modal,
  }))
  rows.sort((a, b) => b.price - a.price)
  const best = rows[0]
  const nearest = [...rows].sort((a, b) => a.market.distanceKm - b.market.distanceKm)[0]
  return {
    cropId,
    best,
    nearest,
    netGainPct: +(((best.price - nearest.price) / nearest.price) * 100).toFixed(1),
  }
}

// ---------------------------------------------------------------------
// Weather
// ---------------------------------------------------------------------
export const weatherToday = {
  location: 'Pune, Maharashtra',
  temperatureC: 29,
  feelsLikeC: 31,
  humidity: 64,
  rainProbability: 35,
  condition: 'Partly Cloudy',
  windKph: 14,
  uvIndex: 6,
  advisory: 'Light showers possible in the evening — avoid harvesting after 4 PM.',
}

export const weatherForecast = Array.from({ length: 7 }).map((_, i) => {
  const conditions = ['Sunny', 'Partly Cloudy', 'Cloudy', 'Light Rain', 'Sunny', 'Partly Cloudy', 'Thunderstorm']
  const rand = seededRandom(i * 17 + 3)
  return {
    date: dateLabel(i),
    day: i === 0 ? 'Today' : new Date(Date.now() + i * 86400000).toLocaleDateString('en-IN', { weekday: 'short' }),
    condition: conditions[i % conditions.length],
    high: Math.round(27 + rand() * 6),
    low: Math.round(19 + rand() * 5),
    rainProbability: Math.round(rand() * 80),
  }
})

// ---------------------------------------------------------------------
// Market comparison
// ---------------------------------------------------------------------
export function getMarketComparison(cropId) {
  const rows = markets.map((m) => {
    const p = currentPrices[cropId][m.id]
    return {
      market: m,
      price: p.modal,
      demand: p.demand,
      arrivalQuintals: p.arrivalQuintals,
      distanceKm: m.distanceKm,
    }
  })
  const maxPrice = Math.max(...rows.map((r) => r.price))
  const recommendedId = rows.find((r) => r.price === maxPrice)?.market.id
  return rows
    .map((r) => ({ ...r, priceDiffPct: +(((r.price - maxPrice) / maxPrice) * 100).toFixed(1) }))
    .map((r) => ({ ...r, recommended: r.market.id === recommendedId }))
}

// ---------------------------------------------------------------------
// Recently analysed crops (dashboard)
// ---------------------------------------------------------------------
export const recentlyAnalyzed = [
  { cropId: 'onion', marketId: 'nashik', analyzedAt: '2 hours ago', recommendation: 'Hold' },
  { cropId: 'tomato', marketId: 'pune', analyzedAt: 'Yesterday', recommendation: 'Sell' },
  { cropId: 'wheat', marketId: 'indore', analyzedAt: '2 days ago', recommendation: 'Sell' },
  { cropId: 'potato', marketId: 'solapur', analyzedAt: '3 days ago', recommendation: 'Hold' },
]

// ---------------------------------------------------------------------
// Analysis history (full page)
// ---------------------------------------------------------------------
export const analysisHistory = [
  { id: 'a1', cropId: 'onion', marketId: 'nashik', date: '27 Aug 2026', predictedPrice: 1980, recommendation: 'Hold' },
  { id: 'a2', cropId: 'tomato', marketId: 'pune', date: '26 Aug 2026', predictedPrice: 1510, recommendation: 'Sell' },
  { id: 'a3', cropId: 'wheat', marketId: 'indore', date: '25 Aug 2026', predictedPrice: 2410, recommendation: 'Sell' },
  { id: 'a4', cropId: 'potato', marketId: 'solapur', date: '24 Aug 2026', predictedPrice: 1145, recommendation: 'Hold' },
  { id: 'a5', cropId: 'rice', marketId: 'azadpur', date: '22 Aug 2026', predictedPrice: 3260, recommendation: 'Sell' },
  { id: 'a6', cropId: 'onion', marketId: 'pune', date: '20 Aug 2026', predictedPrice: 1790, recommendation: 'Hold' },
]

// ---------------------------------------------------------------------
// Notifications
// ---------------------------------------------------------------------
export const notifications = [
  {
    id: 'n1',
    type: 'price-alert',
    title: 'Onion prices up 6.2% at Lasalgaon',
    message: 'Modal price crossed ₹1,980/quintal this morning.',
    time: '32 minutes ago',
    read: false,
  },
  {
    id: 'n2',
    type: 'prediction',
    title: '7-day prediction ready for Wheat',
    message: 'Prices are expected to hold steady at Indore Mandi.',
    time: '3 hours ago',
    read: false,
  },
  {
    id: 'n3',
    type: 'weather',
    title: 'Rain expected this evening',
    message: '35% chance of showers in Pune after 6 PM — plan harvesting accordingly.',
    time: 'Today, 7:00 AM',
    read: true,
  },
  {
    id: 'n4',
    type: 'recommendation',
    title: 'AI suggests selling Tomato stock',
    message: 'Prices may soften over the next 5 days due to rising arrivals.',
    time: 'Yesterday',
    read: true,
  },
  {
    id: 'n5',
    type: 'system',
    title: 'Weekly market summary is ready',
    message: 'Your personalised report for last week is now available.',
    time: '2 days ago',
    read: true,
  },
]

// ---------------------------------------------------------------------
// User profile
// ---------------------------------------------------------------------
export const currentUser = {
  name: 'Ramesh Deshmukh',
  role: 'Farmer',
  location: 'Baramati, Pune District, Maharashtra',
  phone: '+91 98765 43210',
  preferredCrops: ['onion', 'tomato', 'wheat'],
  language: 'en',
  memberSince: 'March 2025',
  farmSizeAcres: 6.5,
}

// ---------------------------------------------------------------------
// AI Assistant — mock Q&A bank
// ---------------------------------------------------------------------
export const assistantSuggestions = [
  'Should I sell my onion today?',
  'Which market has the highest price for wheat?',
  'What is the expected onion price next week?',
  'How is the weather looking for harvesting?',
]

export function getAssistantReply(question) {
  const q = question.toLowerCase()

  if (q.includes('sell') && q.includes('onion')) {
    const rec = getRecommendation()
    return `Based on current trends, I'd suggest **holding** your onion stock for 3–4 more days. ${rec.detail} (Confidence: ${rec.confidence}%)`
  }
  if (q.includes('highest price') || (q.includes('market') && q.includes('wheat'))) {
    const comp = getMarketComparison('wheat').sort((a, b) => b.price - a.price)[0]
    return `${comp.market.name} currently has the highest wheat price at ₹${comp.price.toLocaleString('en-IN')}/quintal, about ${comp.distanceKm} km away.`
  }
  if (q.includes('next week') && q.includes('onion')) {
    const pred = getPrediction('onion', 'nashik')
    return `Onion prices at Nashik Lasalgaon are predicted to reach ₹${pred.sevenDayPrice.toLocaleString('en-IN')}/quintal in 7 days — a ${pred.changePct > 0 ? 'rise' : 'drop'} of ${Math.abs(pred.changePct)}%. Model confidence: ${pred.confidence}%.`
  }
  if (q.includes('weather') || q.includes('harvest')) {
    return `Today in ${weatherToday.location}: ${weatherToday.condition}, ${weatherToday.temperatureC}°C with ${weatherToday.rainProbability}% chance of rain. ${weatherToday.advisory}`
  }
  if (q.includes('tomato')) {
    const pred = getPrediction('tomato', 'pune')
    return `Tomato prices at Pune APMC are trending ${pred.direction === 'up' ? 'upward' : 'downward'}, expected to be ₹${pred.sevenDayPrice.toLocaleString('en-IN')}/quintal in a week (confidence ${pred.confidence}%).`
  }
  return `I'm a demo AI assistant running on mock data right now. Once connected to MCPHub's live prediction engine, I'll be able to answer detailed questions about "${question}" using real market data.`
}
