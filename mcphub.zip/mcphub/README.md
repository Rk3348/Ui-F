# MCPHub — AI-Based Crop Price & Market Intelligence Platform

Frontend-only prototype for the SIH submission. Built with React + Vite,
plain modern CSS (no UI framework), React Router, and Recharts for
data visualisation. All data is realistic **mock data** — no backend,
database, ML model, or MCP server is wired up yet.

## Run it locally

```bash
npm install
npm run dev
```

Then open **http://localhost:5173** in your browser.

To create a production build:

```bash
npm run build
npm run preview
```

## Project structure

```
src/
  components/
    layout/       Sidebar, Header, Layout (app shell)
    ui/           StatCard, CropCard, PriceChart, PredictionChart,
                   MarketCard, WeatherCard, RecommendationCard,
                   ChatMessage, ConfidenceGauge, SelectField,
                   EmptyState, Skeleton, MandiTicker
  pages/           Dashboard, MarketPrices, Prediction, MarketComparison,
                   Weather, Assistant, History, Notifications, Profile,
                   Settings
  context/         ThemeContext (dark/light), LanguageContext (EN/HI/MR)
  data/            mockData.js — single source of truth for mock data
  services/        Thin async wrappers around mockData, shaped like
                   future real API calls (cropService, predictionService,
                   weatherService, assistantService, userDataService)
  styles/          tokens.css, base.css, layout.css, cards.css, forms.css,
                   chat.css, misc.css
```

## Swapping in real data later

Every page calls a function from `src/services/*.js`, never `src/data/mockData.js`
directly. When the backend, ML model, and MCP server are ready, replace the
internals of those service functions with real `fetch()`/MCP calls that
resolve to the **same shapes** — no component or page needs to change.

## Design notes

- Palette: deep botanical green (`--primary`) + harvest amber (`--accent`)
  on a soft sage-tinted background — a distinct "Field & Signal" identity,
  not a generic AI-template look.
- Type: Fraunces (display/serif) for headings and big numbers, Manrope
  (body) for UI text, JetBrains Mono for prices and data.
- Signature element: the scrolling "mandi ticker" on the Dashboard,
  styled like a commodity-exchange ticker with a farm/mandi twist.
- Dark mode and reduced-motion are both supported.
